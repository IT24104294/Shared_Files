# Admin Dashboard Project 
 
## Objective: 
Build a dashboard with a sidebar, cards, and data tables. 
 
## Steps: 
 
## Task: 

## Colors
1. Primary Color: #da712e, rgb(218, 113, 46), hsl(23, 70%, 52%)
2. Secondary Color: #0c1115, rgb(12, 17, 21), hsl(207, 27%, 6%)
3. Background Color: #08080a, rgb(8, 8, 10), hsl(240, 11%, 4%)