# Plugins 
 
## Objective: 
Add official Tailwind plugins. Style forms and typography. 
 
## Steps: 
 
## Task: 
