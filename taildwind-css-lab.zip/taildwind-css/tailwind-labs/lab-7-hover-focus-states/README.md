# Hover and Focus States 
 
## Objective: 
Use state variants like `hover:`, `focus:`, and `active:`. Add transitions and animations. 
 
## Steps: 
 
## Task: 
