# Landing Page Project 
 
## Objective: 
Build a responsive landing page using Tailwind CSS. 
 
## Steps: 
 
## Task: 

## Colors
1. Primary Color: #0a4288, rgb(10, 66, 136), hsl(213, 86%, 29%)
    - #408ee2, rgb(64, 142, 226), hsl(211, 74%, 57%)
2. Secondary Color: #2a2e30, rgb(42, 46, 48), hsl(200, 7%, 18%)
3. Background Color: #0c0d0d, rgb(12, 13, 13), hsl(180, 4%, 5%)