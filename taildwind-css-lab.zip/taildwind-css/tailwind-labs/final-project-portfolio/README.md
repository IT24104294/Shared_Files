# Portfolio Project 
 
## Objective: 
Build a responsive portfolio with a home page, projects section, and contact form. 
 
## Steps: 
 
## Task: 
