# Customizing Tailwind 
 
## Objective: 
Modify the default theme in `tailwind.config.js`. Use `@apply` to reuse Tailwind styles. 
 
## Steps: 
 
## Task: 
