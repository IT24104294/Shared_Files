# E-Commerce Project 
 
## Objective: 
Create a product grid layout and a shopping cart. 
 
## Steps: 
 
## Task: 
