# Dark Mode 
 
## Objective: 
Enable dark mode in `tailwind.config.js`. Apply dark mode-specific classes. 
 
## Steps: 
 
## Task: 
