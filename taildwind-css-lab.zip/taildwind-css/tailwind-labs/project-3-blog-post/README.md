# Blog Post Project 
 
## Objective: 
Design a blog post layout using Tailwind CSS. 
 
## Steps: 
 
## Task: 

## Colors
1. Primary Color: #146cb3, rgb(20, 108, 179), hsl(207, 80%, 39%)
2. Secondary Color: #181a1b, rgb(24, 26, 27), hsl(200, 6%, 10%)
3. Background Color: #2a2d2f, rgb(42, 45, 47), hsl(204, 6%, 17%)