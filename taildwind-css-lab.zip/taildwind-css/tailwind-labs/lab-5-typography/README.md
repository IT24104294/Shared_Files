# Typography 
 
## Objective: 
Use text utilities (`text-lg`, `font-bold`, etc.). Apply responsive typography. 
 
## Steps: 
 
## Task: 
