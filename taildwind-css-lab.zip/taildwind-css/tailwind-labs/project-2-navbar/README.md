# Navbar Project 
 
## Objective: 
Create a responsive navbar using Tailwind CSS. 
 
## Steps: 
 
## Task: 

## Colors
1. Primary Color: #e8e6e3, rgb(232, 230, 227), hsl(36, 10%, 90%)
2. Background Color: #0c0d0d, rgb(12, 13, 13), hsl(180, 4%, 5%)