# Responsive Design 
 
## Objective: 
Understand Tailwind's responsive utilities (`sm`, `md`, `lg`, etc.). Apply breakpoints to modify layouts. 
 
## Steps: 
 
## Task: 
