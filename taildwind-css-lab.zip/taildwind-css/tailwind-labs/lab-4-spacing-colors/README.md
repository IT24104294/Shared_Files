# Spacing and Colors 
 
## Objective: 
Apply spacing utilities (`p-`, `m-`, `gap-`). Use Tailwind's color palette. 
 
## Steps: 
 
## Task: 
