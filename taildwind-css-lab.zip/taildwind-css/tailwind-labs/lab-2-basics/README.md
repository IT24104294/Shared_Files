# Basics of Tailwind CSS 
 
## Objective: 
Understand utility-first CSS. Apply Tailwind's utility classes to style elements. Compare Tailwind with traditional CSS. 
 
## Steps: 
 
## Task: 
